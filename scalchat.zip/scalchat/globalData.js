/**
 * Created by tefino on 15-1-1.
 */
var onlineClient = {};
exports.onlineClient = onlineClient ;