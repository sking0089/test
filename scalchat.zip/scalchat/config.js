/**
 * Created by leotang on 2/16/15.
 */
var pushServerAddress = "http://192.1.1.235:8080"
var databaseServerAddress = "http://192.1.1.235:8080"
exports.PSA = pushServerAddress ;
exports.DSA = databaseServerAddress ;
