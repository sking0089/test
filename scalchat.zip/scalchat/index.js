/**
 * Created by tefino on 2014/10/27.
 */
var server = require('./server.js') ;
server.startServer() ;
